﻿using formatAPI2.Models;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace formatAPI2
{
    public class CouchRepository : ICouchRepository
    {
        private readonly string _couchDbURL;
        private readonly string _couchDbName;
        private readonly string _couchDbUser;
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _httpClientFactory;

        public CouchRepository(IConfiguration configuration, IHttpClientFactory httpClientFactory)
        {
            _configuration = configuration;
            _httpClientFactory = httpClientFactory;
            _couchDbURL = this._configuration["CouchDB:URL"];
            _couchDbName = this._configuration["CouchDB:DBName"];
            _couchDbUser = this._configuration["CouchDB:User"];
        }

        public async Task<HttpClientResponse> GetDocumentASync(string id)
        {
            HttpClientResponse response = new HttpClientResponse();
            var dbClient = DbHttpClient();
            var dbResult = await dbClient.GetAsync(_couchDbName + "/" + id);
            if (dbResult.IsSuccessStatusCode)
            {
                response.IsSuccess = true;
                response.SuccessContentObject = await dbResult.Content.ReadAsStringAsync();
            }
            else
            {
                response.IsSuccess = false;
                response.FailedReason = dbResult.ReasonPhrase;
            }
            return response;
        }

        public async Task<HttpClientResponse> GetDocumentsAsync() 
        {
            HttpClientResponse response = new HttpClientResponse();
            var dbClient = DbHttpClient();
            var dbResult = await dbClient.GetAsync(_couchDbName+ "/_design/getall/_view/new-view");
            if (dbResult.IsSuccessStatusCode)
            {
                response.IsSuccess = true;
                response.SuccessContentObject = await dbResult.Content.ReadAsStringAsync();
            }
            else
            {
                response.IsSuccess = false;
                response.FailedReason = dbResult.ReasonPhrase;
            }
            return response;
        }

        public  async Task<HttpClientResponse> PostDocumentAsync(Property property)
        {
            HttpClientResponse response = new HttpClientResponse();
            var dbClient = this.DbHttpClient();
            
            var jsonData = JsonConvert.SerializeObject(property);
            var httpContent = new StringContent(jsonData, Encoding.UTF8, "application/json");
            var postResult = await dbClient.PostAsync(_couchDbName, httpContent).ConfigureAwait(true);

            if (postResult.IsSuccessStatusCode)
            {
                response.IsSuccess = true;
                response.SuccessContentObject = await postResult.Content.ReadAsStringAsync();
            }
            else
            {
                response.IsSuccess = false;
                response.FailedReason = postResult.ReasonPhrase;
            }

            return response;
        }

        public async Task<HttpClientResponse> PostDocumentAsync(AdvertUnit advertUnit)
        {
            HttpClientResponse response = new HttpClientResponse();
            var dbClient = this.DbHttpClient();

            var jsonData = JsonConvert.SerializeObject(advertUnit);
            var httpContent = new StringContent(jsonData, Encoding.UTF8, "application/json");
            var postResult = await dbClient.PostAsync(_couchDbName, httpContent).ConfigureAwait(true);

            if (postResult.IsSuccessStatusCode)
            {
                response.IsSuccess = true;
                response.SuccessContentObject = await postResult.Content.ReadAsStringAsync();
            }
            else
            {
                response.IsSuccess = false;
                response.FailedReason = postResult.ReasonPhrase;
            }

            return response;
        }

        private HttpClient DbHttpClient()
        {
            var httpClient = this._httpClientFactory.CreateClient();
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Clear();

            httpClient.BaseAddress = new Uri(_couchDbURL);
            var dbUserByteArray = Encoding.ASCII.GetBytes(_couchDbUser);
            httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(dbUserByteArray));
            //httpClient.DefaultRequestHeaders.Add("Authorization", "Basic" + Convert.ToBase64String(dbUserByteArray));
            return httpClient;
        }
    }
}
