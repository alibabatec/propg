﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace formatAPI2.Models
{
    public class AdvertUnitView
    {
        public AdvertUnit value { get; set; }
    }
    public class AdvertUnit
    {
        public double RentPerMonth { get; set; }
        public String RentalType { get; set; }
        public String AdvertisedBy { get; set; }
        public String StayDuration { get; set; }
        public String Region { get; set; }
        public String District { get; set; }
        public String Address1 { get; set; }
        public String OccupationPreference { get; set; }
        public String GenderPreference { get; set; }
        public String[] Features { get; set; }
        public String PropertyTitle { get; set; }
        public String PropertyDescription { get; set; }
    }

    public class FilterOption
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}
