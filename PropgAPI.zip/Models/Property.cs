﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace formatAPI2
{
    public class Property
    {
        public String Name { get; set; }
        public String Location { get; set; }
        public String OwnerName { get; set; }

        
    }
}
