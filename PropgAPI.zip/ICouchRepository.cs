﻿using formatAPI2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace formatAPI2
{
    public interface ICouchRepository
    {
        Task<HttpClientResponse> PostDocumentAsync(Property property);

        Task<HttpClientResponse> PostDocumentAsync(AdvertUnit advertUnit);

        Task<HttpClientResponse> GetDocumentsAsync();
        Task<HttpClientResponse> GetDocumentASync(string id);
    }
}
