﻿using formatAPI2.Models;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace formatAPI2.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AdvertUnitController : ControllerBase
    {
        private readonly ICouchRepository _couchRepository;
        public AdvertUnitController(ICouchRepository couchRepository)
        {
            this._couchRepository = couchRepository;    
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] AdvertUnit advertUnit)
        {
            var result = await _couchRepository.PostDocumentAsync(advertUnit);
            if (result.IsSuccess)
            {
                var sResult = JsonConvert.DeserializeObject<SavedResult>(result.SuccessContentObject);
                return new CreatedResult("Success", sResult);
            }
            return new UnprocessableEntityObjectResult(result.FailedReason);

        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var result = await _couchRepository.GetDocumentsAsync();
            if (result.IsSuccess)
            {   
                var sResult = result.SuccessContentObject;
                return new CreatedResult("Success", sResult);
            }
            return new NotFoundObjectResult(result.FailedReason);
        }
    }
}
