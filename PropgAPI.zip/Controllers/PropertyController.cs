﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace formatAPI2.Controllers
{
    [Route("[controller]")]
    [ApiController]

    public class PropertyController : ControllerBase
    {
        private readonly ICouchRepository _couchRepository;

        public PropertyController(ICouchRepository couchRepository)
        {
            _couchRepository = couchRepository;
        }

        [HttpGet("id")]
        public async Task<IActionResult> Get(string id)
        {
            var result = await _couchRepository.GetDocumentASync(id);
            if (result.IsSuccess)
            {
                var sresult = JsonConvert.DeserializeObject<Property>(result.SuccessContentObject);
                return new OkObjectResult(sresult);
            }
            return new NotFoundObjectResult("Not Found");
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Property property)
        {
            var result = await _couchRepository.PostDocumentAsync(property);
            if (result.IsSuccess)
            {
                var sResult = JsonConvert.DeserializeObject<SavedResult>(result.SuccessContentObject);
                return new CreatedResult("Success", sResult); ;
            }
            return new UnprocessableEntityObjectResult(result.FailedReason);
        }

        

    }
}
